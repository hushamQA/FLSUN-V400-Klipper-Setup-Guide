#!/bin/bash
# Re-apply sdbus patch after git pull
/usr/local/bin/patch-ks-sdbus.sh
