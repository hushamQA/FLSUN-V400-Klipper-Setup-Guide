#!/bin/bash
# Auto-patch KlipperScreen sdbus_nm.py for libsystemd 245 compatibility
FILE="/home/pi/KlipperScreen/ks_includes/sdbus_nm.py"
PATCH_MARKER="# PATCHED_FOR_LIBSYSTEMD_245"

if [ -f "$FILE" ] && ! grep -q "$PATCH_MARKER" "$FILE" 2>/dev/null; then
    if grep -q "NetworkManagerConnectionProperties" "$FILE" 2>/dev/null; then
        # Remove the problematic import line
        sed -i '/NetworkManagerConnectionProperties,/d' "$FILE"
        # Remove the type annotation
        sed -i 's/properties: NetworkManagerConnectionProperties = {/properties = {/' "$FILE"
        # Add patch marker
        sed -i "1a\\$PATCH_MARKER" "$FILE"
        echo "KlipperScreen sdbus_nm.py patched successfully"
    else
        echo "KlipperScreen sdbus_nm.py already patched or not needed"
    fi
fi
